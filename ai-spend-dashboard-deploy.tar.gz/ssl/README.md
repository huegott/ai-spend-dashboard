# SSL Certificates

This directory should contain your SSL certificates for HTTPS deployment.

Required files for production:
- `cert.pem` - SSL certificate
- `privkey.pem` - Private key

## Generating Self-Signed Certificates (for testing)

You can generate self-signed certificates for testing:

```bash
openssl req -x509 -newkey rsa:4096 -keyout privkey.pem -out cert.pem -days 365 -nodes
```

## Production Certificates

For production deployment at https://10.10.10.20:9443, you'll need proper SSL certificates:

1. **Let's Encrypt** (recommended for public domains)
2. **Internal CA** certificates for internal networks
3. **Commercial SSL** certificates from providers like DigiCert, Comodo, etc.

## File Permissions

Ensure proper permissions for security:

```bash
chmod 600 privkey.pem
chmod 644 cert.pem
```

## Docker Volume Mounting

The SSL certificates are mounted as read-only volumes in the Docker container:

```yaml
volumes:
  - ./ssl:/app/ssl:ro
```