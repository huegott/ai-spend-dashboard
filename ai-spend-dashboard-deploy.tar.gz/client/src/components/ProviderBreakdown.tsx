import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

interface ProviderBreakdownProps {
  data: Array<{
    provider: string;
    total_spend: number;
  }>;
  isLoading?: boolean;
}

const COLORS = {
  openai: '#10b981', // green
  anthropic: '#8b5cf6', // purple
  default: '#6b7280' // gray
};

const ProviderBreakdown: React.FC<ProviderBreakdownProps> = ({ data, isLoading }) => {
  const chartData = data.map(item => ({
    name: item.provider.charAt(0).toUpperCase() + item.provider.slice(1),
    value: parseFloat(item.total_spend.toString()),
    provider: item.provider
  }));

  const totalSpend = chartData.reduce((sum, item) => sum + item.value, 0);

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow p-6 border border-gray-200">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Spend by Provider</h3>
        <div className="animate-pulse">
          <div className="h-64 bg-gray-300 rounded"></div>
        </div>
      </div>
    );
  }

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0];
      const percentage = totalSpend > 0 ? (data.value / totalSpend * 100).toFixed(1) : '0.0';
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium">{data.payload.name}</p>
          <p className="text-blue-600">
            ${data.value.toFixed(2)} ({percentage}%)
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white rounded-lg shadow p-6 border border-gray-200">
      <h3 className="text-lg font-medium text-gray-900 mb-4">
        Spend by Provider
      </h3>
      
      {chartData.length > 0 ? (
        <div>
          <div style={{ width: '100%', height: 250 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(1)}%`}
                >
                  {chartData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={COLORS[entry.provider as keyof typeof COLORS] || COLORS.default} 
                    />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          <div className="mt-4 space-y-2">
            {chartData.map((item) => (
              <div key={item.provider} className="flex items-center justify-between text-sm">
                <div className="flex items-center">
                  <div 
                    className="w-3 h-3 rounded-full mr-2" 
                    style={{ 
                      backgroundColor: COLORS[item.provider as keyof typeof COLORS] || COLORS.default 
                    }}
                  ></div>
                  <span className="text-gray-700">{item.name}</span>
                </div>
                <div className="font-medium text-gray-900">
                  ${item.value.toFixed(2)}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-center h-64 text-gray-500">
          <div className="text-center">
            <p className="text-lg">No provider data</p>
            <p className="text-sm">Sync your API data to see provider breakdown</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProviderBreakdown;