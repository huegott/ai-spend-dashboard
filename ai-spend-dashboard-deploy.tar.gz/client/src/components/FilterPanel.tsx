import React, { useState } from 'react';
import { Calendar, Filter, Download, Sync } from 'lucide-react';
import { FilterOptions, SyncStatus } from '../types';

interface FilterPanelProps {
  filters: FilterOptions;
  onFiltersChange: (filters: Partial<FilterOptions>) => void;
  onSyncOpenAI: (days: number) => Promise<void>;
  syncStatus: SyncStatus | null;
  isLoading: boolean;
}

const FilterPanel: React.FC<FilterPanelProps> = ({
  filters,
  onFiltersChange,
  onSyncOpenAI,
  syncStatus,
  isLoading
}) => {
  const [isSyncing, setIsSyncing] = useState(false);

  const handleSyncOpenAI = async () => {
    setIsSyncing(true);
    try {
      await onSyncOpenAI(30);
    } catch (error) {
      console.error('Sync failed:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  const getQuickDateRange = (days: number) => {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    return {
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0]
    };
  };

  const quickRanges = [
    { label: 'Last 7 days', days: 7 },
    { label: 'Last 30 days', days: 30 },
    { label: 'Last 90 days', days: 90 }
  ];

  return (
    <div className="bg-white rounded-lg shadow p-4 border border-gray-200">
      <div className="flex flex-wrap items-center gap-4">
        {/* Date Range */}
        <div className="flex items-center space-x-2">
          <Calendar className="w-4 h-4 text-gray-500" />
          <input
            type="date"
            value={filters.startDate || ''}
            onChange={(e) => onFiltersChange({ startDate: e.target.value })}
            className="border border-gray-300 rounded-md px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          />
          <span className="text-gray-500">to</span>
          <input
            type="date"
            value={filters.endDate || ''}
            onChange={(e) => onFiltersChange({ endDate: e.target.value })}
            className="border border-gray-300 rounded-md px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          />
        </div>

        {/* Quick Date Ranges */}
        <div className="flex items-center space-x-2">
          {quickRanges.map((range) => (
            <button
              key={range.days}
              onClick={() => onFiltersChange(getQuickDateRange(range.days))}
              className="px-3 py-1 text-xs font-medium text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
            >
              {range.label}
            </button>
          ))}
        </div>

        {/* Provider Filter */}
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-gray-500" />
          <select
            value={filters.provider || 'all'}
            onChange={(e) => onFiltersChange({ provider: e.target.value as any })}
            className="border border-gray-300 rounded-md px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          >
            <option value="all">All Providers</option>
            <option value="openai">OpenAI</option>
            <option value="anthropic">Anthropic</option>
          </select>
        </div>

        {/* Sync Button */}
        <div className="ml-auto flex items-center space-x-2">
          {syncStatus?.openaiConfigured && (
            <button
              onClick={handleSyncOpenAI}
              disabled={isSyncing || isLoading}
              className="inline-flex items-center px-3 py-1 border border-green-300 text-sm font-medium rounded-md text-green-700 bg-green-50 hover:bg-green-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Sync className={`w-4 h-4 mr-1 ${isSyncing ? 'animate-spin' : ''}`} />
              {isSyncing ? 'Syncing...' : 'Sync OpenAI'}
            </button>
          )}
          
          <button
            disabled={isLoading}
            className="inline-flex items-center px-3 py-1 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Download className="w-4 h-4 mr-1" />
            Export
          </button>
        </div>
      </div>

      {/* Sync Status Indicator */}
      {syncStatus && (
        <div className="mt-3 pt-3 border-t border-gray-200">
          <div className="flex items-center justify-between text-xs text-gray-500">
            <div className="flex items-center space-x-4">
              {syncStatus.providers.map((provider) => (
                <div key={provider.provider} className="flex items-center space-x-1">
                  <div className={`w-2 h-2 rounded-full ${
                    provider.total_records > 0 ? 'bg-green-500' : 'bg-gray-300'
                  }`}></div>
                  <span className="capitalize">{provider.provider}</span>
                  <span>({provider.total_records} records)</span>
                </div>
              ))}
            </div>
            <div>
              Last check: {new Date(syncStatus.lastSyncCheck).toLocaleTimeString()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FilterPanel;