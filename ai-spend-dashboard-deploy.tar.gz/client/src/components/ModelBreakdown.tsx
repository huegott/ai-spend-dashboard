import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface ModelBreakdownProps {
  data: Array<{
    provider: string;
    model_name: string;
    total_spend: number;
    total_tokens: number;
    total_requests: number;
  }>;
  isLoading?: boolean;
}

const ModelBreakdown: React.FC<ModelBreakdownProps> = ({ data, isLoading }) => {
  // Take top 10 models by spend and format for chart
  const chartData = data
    .slice(0, 10)
    .map(item => ({
      model: item.model_name.length > 15 
        ? item.model_name.substring(0, 15) + '...' 
        : item.model_name,
      fullModel: item.model_name,
      spend: parseFloat(item.total_spend.toString()),
      tokens: item.total_tokens,
      requests: item.total_requests,
      provider: item.provider
    }));

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow p-6 border border-gray-200">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Top Models by Spend</h3>
        <div className="animate-pulse">
          <div className="h-64 bg-gray-300 rounded"></div>
        </div>
      </div>
    );
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium">{data.fullModel}</p>
          <p className="text-blue-600">Spend: ${data.spend.toFixed(4)}</p>
          <p className="text-gray-600">Tokens: {data.tokens.toLocaleString()}</p>
          <p className="text-gray-600">Requests: {data.requests.toLocaleString()}</p>
          <p className="text-gray-500 capitalize">Provider: {data.provider}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white rounded-lg shadow p-6 border border-gray-200">
      <h3 className="text-lg font-medium text-gray-900 mb-4">
        Top Models by Spend
      </h3>
      
      {chartData.length > 0 ? (
        <div>
          <div style={{ width: '100%', height: 250 }}>
            <ResponsiveContainer>
              <BarChart data={chartData} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis 
                  type="number" 
                  stroke="#6b7280"
                  fontSize={12}
                  tickFormatter={(value) => `$${value.toFixed(2)}`}
                />
                <YAxis 
                  type="category" 
                  dataKey="model" 
                  stroke="#6b7280"
                  fontSize={12}
                  width={120}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar 
                  dataKey="spend" 
                  fill="#3b82f6"
                  radius={[0, 4, 4, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
          
          <div className="mt-4">
            <div className="text-xs text-gray-500 mb-2">Detailed breakdown:</div>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {data.slice(0, 5).map((item, index) => (
                <div key={index} className="flex items-center justify-between text-sm py-1">
                  <div className="flex items-center min-w-0">
                    <div className={`w-2 h-2 rounded-full mr-2 ${
                      item.provider === 'openai' ? 'bg-green-500' : 'bg-purple-500'
                    }`}></div>
                    <span className="text-gray-700 truncate" title={item.model_name}>
                      {item.model_name}
                    </span>
                  </div>
                  <div className="font-medium text-gray-900 ml-2">
                    ${item.total_spend.toFixed(4)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-center h-64 text-gray-500">
          <div className="text-center">
            <p className="text-lg">No model data</p>
            <p className="text-sm">Sync your API data to see model breakdown</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ModelBreakdown;