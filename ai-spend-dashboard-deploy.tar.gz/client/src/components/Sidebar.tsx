import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Home, 
  BarChart3, 
  Settings, 
  Database,
  GitBranch,
  Workflow
} from 'lucide-react';

const navigation = [
  { name: 'Dashboard', href: '/', icon: Home },
  { name: 'Analytics', href: '/analytics', icon: BarChart3 },
  { name: 'Data Sync', href: '/sync', icon: Database },
  { name: 'MCP Integrations', href: '/mcp', icon: GitBranch },
  { name: 'Workflows', href: '/workflows', icon: Workflow },
  { name: 'Settings', href: '/settings', icon: Settings },
];

const Sidebar: React.FC = () => {
  return (
    <div className="flex flex-col w-64 bg-white shadow-sm border-r border-gray-200">
      <div className="flex-1 flex flex-col min-h-0">
        <nav className="flex-1 px-2 py-4 space-y-1">
          {navigation.map((item) => (
            <NavLink
              key={item.name}
              to={item.href}
              className={({ isActive }) =>
                `group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors ${
                  isActive
                    ? 'bg-primary-100 text-primary-700 border-r-2 border-primary-500'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`
              }
            >
              <item.icon
                className="mr-3 flex-shrink-0 h-5 w-5"
                aria-hidden="true"
              />
              {item.name}
            </NavLink>
          ))}
        </nav>
        
        <div className="px-2 py-4 border-t border-gray-200">
          <div className="text-xs text-gray-500 mb-2">Quick Stats</div>
          <div className="space-y-1">
            <div className="text-sm">
              <span className="text-gray-600">Total Spend:</span>
              <span className="ml-2 font-semibold text-gray-900">$0.00</span>
            </div>
            <div className="text-sm">
              <span className="text-gray-600">This Month:</span>
              <span className="ml-2 font-semibold text-gray-900">$0.00</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;