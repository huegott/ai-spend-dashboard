import React from 'react';
import { useDashboard } from '../hooks/useDashboard';
import SpendSummary from './SpendSummary';
import SpendChart from './SpendChart';
import ProviderBreakdown from './ProviderBreakdown';
import ModelBreakdown from './ModelBreakdown';
import FilterPanel from './FilterPanel';
import LoadingSpinner from './LoadingSpinner';
import ErrorAlert from './ErrorAlert';

const Dashboard: React.FC = () => {
  const { 
    data, 
    syncStatus, 
    loading, 
    error, 
    filters, 
    updateFilters, 
    refresh, 
    syncOpenAI 
  } = useDashboard();

  if (error) {
    return (
      <div className="max-w-7xl mx-auto">
        <ErrorAlert message={error} onRetry={refresh} />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          AI Spend Overview
        </h1>
        <p className="text-gray-600">
          Monitor your AI API usage and costs across providers
        </p>
      </div>

      {/* Filter Panel */}
      <div className="mb-6">
        <FilterPanel
          filters={filters}
          onFiltersChange={updateFilters}
          onSyncOpenAI={syncOpenAI}
          syncStatus={syncStatus}
          isLoading={loading}
        />
      </div>

      {loading && !data ? (
        <LoadingSpinner />
      ) : data ? (
        <div className="space-y-6">
          {/* Summary Cards */}
          <SpendSummary
            totalSpend={data.totalSpend}
            spendByProvider={data.spendByProvider}
            isLoading={loading}
          />

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Daily Spend Trend */}
            <div className="lg:col-span-2">
              <SpendChart
                data={data.dailyTrend}
                title="Daily Spend Trend"
                isLoading={loading}
              />
            </div>

            {/* Provider Breakdown */}
            <ProviderBreakdown
              data={data.spendByProvider}
              isLoading={loading}
            />

            {/* Model Breakdown */}
            <ModelBreakdown
              data={data.spendByModel}
              isLoading={loading}
            />
          </div>

          {/* Additional Info */}
          {syncStatus && (
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="text-sm font-medium text-gray-900 mb-2">
                Data Sync Status
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {syncStatus.providers.map((provider) => (
                  <div key={provider.provider} className="bg-white rounded p-3 border border-gray-200">
                    <div className="text-sm font-medium text-gray-900 capitalize mb-1">
                      {provider.provider}
                    </div>
                    <div className="text-xs text-gray-600 space-y-1">
                      <div>Records: {provider.total_records.toLocaleString()}</div>
                      <div>Total: ${provider.total_spend.toFixed(2)}</div>
                      <div>Latest: {provider.latest_date}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : null}
    </div>
  );
};

export default Dashboard;