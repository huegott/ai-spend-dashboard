import React from 'react';
import { TrendingUp, TrendingDown, DollarSign } from 'lucide-react';

interface SpendSummaryProps {
  totalSpend: number;
  spendByProvider: Array<{
    provider: string;
    total_spend: number;
  }>;
  isLoading?: boolean;
}

const SpendSummary: React.FC<SpendSummaryProps> = ({ 
  totalSpend, 
  spendByProvider, 
  isLoading 
}) => {
  const openaiSpend = spendByProvider.find(p => p.provider === 'openai')?.total_spend || 0;
  const anthropicSpend = spendByProvider.find(p => p.provider === 'anthropic')?.total_spend || 0;

  const cards = [
    {
      title: 'Total Spend',
      value: totalSpend,
      icon: DollarSign,
      color: 'blue',
      change: null
    },
    {
      title: 'OpenAI',
      value: openaiSpend,
      icon: TrendingUp,
      color: 'green',
      change: null
    },
    {
      title: 'Anthropic',
      value: anthropicSpend,
      icon: TrendingUp,
      color: 'purple',
      change: null
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      {cards.map((card) => (
        <div
          key={card.title}
          className="bg-white rounded-lg shadow p-6 border border-gray-200"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">
                {card.title}
              </p>
              <p className="text-2xl font-bold text-gray-900">
                {isLoading ? (
                  <span className="animate-pulse bg-gray-300 h-8 w-20 rounded"></span>
                ) : (
                  `$${card.value.toFixed(2)}`
                )}
              </p>
              {card.change && (
                <div className="flex items-center mt-2">
                  {card.change > 0 ? (
                    <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-red-500 mr-1" />
                  )}
                  <span className={`text-sm ${
                    card.change > 0 ? 'text-green-500' : 'text-red-500'
                  }`}>
                    {Math.abs(card.change).toFixed(1)}%
                  </span>
                  <span className="text-sm text-gray-500 ml-1">vs last month</span>
                </div>
              )}
            </div>
            <div className={`p-3 rounded-full ${
              card.color === 'blue' ? 'bg-blue-100' :
              card.color === 'green' ? 'bg-green-100' : 'bg-purple-100'
            }`}>
              <card.icon className={`w-6 h-6 ${
                card.color === 'blue' ? 'text-blue-600' :
                card.color === 'green' ? 'text-green-600' : 'text-purple-600'
              }`} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SpendSummary;