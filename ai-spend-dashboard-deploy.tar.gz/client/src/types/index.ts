export interface SpendData {
  id: string;
  provider: 'openai' | 'anthropic';
  model_name: string;
  date: string;
  cost_usd: number;
  input_tokens: number;
  output_tokens: number;
  total_tokens: number;
  num_requests: number;
  project_id?: string;
  api_key_id?: string;
  user_id?: string;
  metadata?: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface DashboardSummary {
  totalSpend: number;
  spendByProvider: Array<{
    provider: string;
    total_spend: number;
  }>;
  spendByModel: Array<{
    provider: string;
    model_name: string;
    total_spend: number;
    total_tokens: number;
    total_requests: number;
  }>;
  dailyTrend: Array<{
    date: string;
    daily_spend: number;
  }>;
}

export interface ApiResponse<T> {
  data?: T;
  error?: string;
  pagination?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface FilterOptions {
  startDate?: string;
  endDate?: string;
  provider?: 'all' | 'openai' | 'anthropic';
  model?: string;
  projectId?: string;
  apiKeyId?: string;
}

export interface Model {
  provider: 'openai' | 'anthropic';
  model_name: string;
}

export interface Project {
  project_id: string;
}

export interface ApiKey {
  api_key_id: string;
}

export interface SyncStatus {
  providers: Array<{
    provider: string;
    total_records: number;
    latest_date: string;
    total_spend: number;
    last_updated: string;
  }>;
  openaiConfigured: boolean;
  lastSyncCheck: string;
}

export interface MCPIntegration {
  id: string;
  integration_type: 'portainer' | 'github' | 'n8n' | 'asana';
  integration_name: string;
  is_active: boolean;
  last_sync?: string;
  config: string[];
}

export interface Task {
  id: string;
  external_id: string;
  integration_type: string;
  title: string;
  description?: string;
  status: string;
  priority?: string;
  assignee?: string;
  labels: string[];
  due_date?: string;
  external_url?: string;
  metadata: Record<string, any>;
  created_at: string;
  updated_at: string;
}