import { useState, useEffect, useCallback } from 'react';
import { dashboardApi, spendApi } from '../services/api';
import { DashboardSummary, FilterOptions, SyncStatus } from '../types';

export const useDashboard = (initialFilters?: FilterOptions) => {
  const [data, setData] = useState<DashboardSummary | null>(null);
  const [syncStatus, setSyncStatus] = useState<SyncStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<FilterOptions>(initialFilters || {
    startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 days ago
    endDate: new Date().toISOString().split('T')[0],
    provider: 'all'
  });

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const [dashboardData, statusData] = await Promise.all([
        dashboardApi.getSummary(filters),
        spendApi.getSyncStatus()
      ]);
      
      setData(dashboardData);
      setSyncStatus(statusData);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch dashboard data';
      setError(errorMessage);
      console.error('Dashboard fetch error:', err);
    } finally {
      setLoading(false);
    }
  }, [filters]);

  const updateFilters = useCallback((newFilters: Partial<FilterOptions>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  }, []);

  const refresh = useCallback(() => {
    fetchData();
  }, [fetchData]);

  const syncOpenAI = useCallback(async (days: number = 30) => {
    try {
      setLoading(true);
      await spendApi.syncOpenAI(days);
      await fetchData(); // Refresh data after sync
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to sync OpenAI data';
      setError(errorMessage);
      console.error('OpenAI sync error:', err);
    } finally {
      setLoading(false);
    }
  }, [fetchData]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return {
    data,
    syncStatus,
    loading,
    error,
    filters,
    updateFilters,
    refresh,
    syncOpenAI
  };
};