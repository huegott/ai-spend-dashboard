import axios from 'axios';
import { 
  DashboardSummary, 
  SpendData, 
  ApiResponse, 
  FilterOptions, 
  Model, 
  Project, 
  ApiKey, 
  SyncStatus,
  MCPIntegration,
  Task
} from '../types';

const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? '/api' 
  : 'http://localhost:3000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
});

// Request interceptor for logging
api.interceptors.request.use((config) => {
  console.log(`API Request: ${config.method?.toUpperCase()} ${config.url}`);
  return config;
});

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API Error:', error.response?.data || error.message);
    return Promise.reject(error);
  }
);

export const dashboardApi = {
  getSummary: async (filters?: FilterOptions): Promise<DashboardSummary> => {
    const response = await api.get('/dashboard/summary', { params: filters });
    return response.data;
  },

  getSpendData: async (filters?: FilterOptions & { page?: number; limit?: number }): Promise<ApiResponse<SpendData[]>> => {
    const response = await api.get('/spend', { params: filters });
    return response.data;
  },

  getModels: async (provider?: string): Promise<Model[]> => {
    const response = await api.get('/models', { params: { provider } });
    return response.data;
  },

  getProjects: async (): Promise<Project[]> => {
    const response = await api.get('/projects');
    return response.data;
  },

  getApiKeys: async (provider?: string): Promise<ApiKey[]> => {
    const response = await api.get('/api-keys', { params: { provider } });
    return response.data;
  }
};

export const spendApi = {
  syncOpenAI: async (days: number = 30) => {
    const response = await api.post('/spend/sync/openai', { days });
    return response.data;
  },

  addAnthropicData: async (data: {
    date: string;
    model_name: string;
    cost_usd: number;
    input_tokens?: number;
    output_tokens?: number;
    num_requests?: number;
    metadata?: Record<string, any>;
  }) => {
    const response = await api.post('/spend/anthropic/manual', data);
    return response.data;
  },

  bulkImport: async (records: Array<{
    provider: string;
    date: string;
    model_name: string;
    cost_usd: number;
    input_tokens?: number;
    output_tokens?: number;
    num_requests?: number;
    project_id?: string;
    api_key_id?: string;
    user_id?: string;
    metadata?: Record<string, any>;
  }>) => {
    const response = await api.post('/spend/manual/bulk', { records });
    return response.data;
  },

  getSyncStatus: async (): Promise<SyncStatus> => {
    const response = await api.get('/spend/sync/status');
    return response.data;
  }
};

export const mcpApi = {
  getIntegrations: async (): Promise<{ integrations: MCPIntegration[] }> => {
    const response = await api.get('/mcp/integrations');
    return response.data;
  },

  addIntegration: async (integration: {
    integration_type: string;
    integration_name: string;
    config: Record<string, any>;
  }) => {
    const response = await api.post('/mcp/integrations', integration);
    return response.data;
  },

  getTasks: async (filters?: {
    integration_type?: string;
    status?: string;
    assignee?: string;
  }): Promise<{ tasks: Task[] }> => {
    const response = await api.get('/mcp/tasks', { params: filters });
    return response.data;
  },

  syncIntegration: async (integrationType: string) => {
    const response = await api.post(`/mcp/sync/${integrationType}`);
    return response.data;
  }
};

export default api;